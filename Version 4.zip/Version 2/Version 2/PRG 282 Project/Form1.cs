namespace PRG_282_Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

         private void label1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

    
    }
}
