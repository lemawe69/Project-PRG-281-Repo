﻿namespace PRG_282_Project
{
	partial class Form1
	{
		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			menuStrip1 = new MenuStrip();
			homeToolStripMenuItem = new ToolStripMenuItem();
			addNewStudentToolStripMenuItem = new ToolStripMenuItem();
			updateStudentInfoToolStripMenuItem = new ToolStripMenuItem();
			deleteStudentToolStripMenuItem = new ToolStripMenuItem();
			generateSumaryToolStripMenuItem = new ToolStripMenuItem();
			accessDataBaseToolStripMenuItem = new ToolStripMenuItem();
			menuStrip1.SuspendLayout();
			SuspendLayout();
			// 
			// menuStrip1
			// 
			menuStrip1.BackColor = SystemColors.ActiveCaption;
			menuStrip1.Font = new Font("Segoe UI", 12F);
			menuStrip1.Items.AddRange(new ToolStripItem[] { homeToolStripMenuItem, addNewStudentToolStripMenuItem, updateStudentInfoToolStripMenuItem, deleteStudentToolStripMenuItem, generateSumaryToolStripMenuItem, accessDataBaseToolStripMenuItem });
			menuStrip1.Location = new Point(0, 0);
			menuStrip1.Name = "menuStrip1";
			menuStrip1.RightToLeft = RightToLeft.No;
			menuStrip1.Size = new Size(800, 29);
			menuStrip1.TabIndex = 0;
			menuStrip1.Text = "menuStrip1";
			menuStrip1.ItemClicked += menuStrip1_ItemClicked;
			// 
			// homeToolStripMenuItem
			// 
			homeToolStripMenuItem.Name = "homeToolStripMenuItem";
			homeToolStripMenuItem.Size = new Size(64, 25);
			homeToolStripMenuItem.Text = "Home";
			// 
			// addNewStudentToolStripMenuItem
			// 
			addNewStudentToolStripMenuItem.Name = "addNewStudentToolStripMenuItem";
			addNewStudentToolStripMenuItem.Size = new Size(143, 25);
			addNewStudentToolStripMenuItem.Text = "Add New Student";
			// 
			// updateStudentInfoToolStripMenuItem
			// 
			updateStudentInfoToolStripMenuItem.Name = "updateStudentInfoToolStripMenuItem";
			updateStudentInfoToolStripMenuItem.Size = new Size(160, 25);
			updateStudentInfoToolStripMenuItem.Text = "Update Student Info";
			// 
			// deleteStudentToolStripMenuItem
			// 
			deleteStudentToolStripMenuItem.Name = "deleteStudentToolStripMenuItem";
			deleteStudentToolStripMenuItem.Size = new Size(123, 25);
			deleteStudentToolStripMenuItem.Text = "Delete Student";
			// 
			// generateSumaryToolStripMenuItem
			// 
			generateSumaryToolStripMenuItem.Name = "generateSumaryToolStripMenuItem";
			generateSumaryToolStripMenuItem.Size = new Size(143, 25);
			generateSumaryToolStripMenuItem.Text = "Generate Sumary";
			// 
			// accessDataBaseToolStripMenuItem
			// 
			accessDataBaseToolStripMenuItem.Name = "accessDataBaseToolStripMenuItem";
			accessDataBaseToolStripMenuItem.Size = new Size(136, 25);
			accessDataBaseToolStripMenuItem.Text = "Access DataBase";
			// 
			// Form1
			// 
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(800, 450);
			Controls.Add(menuStrip1);
			MainMenuStrip = menuStrip1;
			Name = "Form1";
			Text = "Form1";
			menuStrip1.ResumeLayout(false);
			menuStrip1.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private MenuStrip menuStrip1;
		private ToolStripMenuItem homeToolStripMenuItem;
		private ToolStripMenuItem addNewStudentToolStripMenuItem;
		private ToolStripMenuItem updateStudentInfoToolStripMenuItem;
		private ToolStripMenuItem deleteStudentToolStripMenuItem;
		private ToolStripMenuItem generateSumaryToolStripMenuItem;
		private ToolStripMenuItem accessDataBaseToolStripMenuItem;
	}
}
