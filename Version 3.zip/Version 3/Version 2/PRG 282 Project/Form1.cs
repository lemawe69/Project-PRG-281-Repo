namespace PRG_282_Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void insertStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowStudentForm();
        }

        private void ShowStudentForm()
        {
            // Clear existing controls on the panel
            panel1.Controls.Clear();

            // Create labels and textboxes for student details

            Label lblID = new Label { Text = "Student ID:", Location = new Point(20, 20) };
            TextBox txtID = new TextBox { Location = new Point(120, 20), Width = 200 };

            Label lblName = new Label { Text = "Name:", Location = new Point(20, 60) };
            TextBox txtName = new TextBox { Location = new Point(120, 60), Width = 200 };

            Label lblSurname = new Label { Text = "Surname:", Location = new Point(20, 100) };
            TextBox txtSurname = new TextBox { Location = new Point(120, 100), Width = 200 };

            Label lblAge = new Label { Text = "Age:", Location = new Point(20, 140) };
            TextBox txtAge = new TextBox { Location = new Point(120, 140), Width = 200 };

            Label lblCourse = new Label { Text = "Course:", Location = new Point(20, 180) };
            TextBox txtCourse = new TextBox { Location = new Point(120, 180), Width = 200 };

            Label lblYoS = new Label { Text = "Years of Study:", Location = new Point(20, 220) };
            TextBox txtYos = new TextBox { Location = new Point(120, 220), Width = 200 };

            // Add a button to save the input
            Button btnSave = new Button
            {
                Text = "Save",
                Location = new Point(100, 260)
            };
            btnSave.Click += (s, e) => SaveStudent(txtID.Text,txtName.Text,txtSurname.Text,txtAge.Text,txtCourse.Text,txtYos.Text);


            // Add controls to the panel
            panel1.Controls.Add(lblID);
            panel1.Controls.Add(txtID);
            panel1.Controls.Add(lblName);
            panel1.Controls.Add(txtName);
            panel1.Controls.Add(lblSurname);
            panel1.Controls.Add(txtSurname);
            panel1.Controls.Add(lblAge);
            panel1.Controls.Add(txtAge);
            panel1.Controls.Add(lblCourse);
            panel1.Controls.Add(txtCourse);
            panel1.Controls.Add(lblYoS);
            panel1.Controls.Add(txtYos);
            panel1.Controls.Add(btnSave);
        }

        private void SaveStudent(string id, string name, string surname, string age, string course, string yearsOfStudy)
        {
            // Validate input fields
            if (string.IsNullOrWhiteSpace(id) || string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(surname) ||
                string.IsNullOrWhiteSpace(age) || string.IsNullOrWhiteSpace(course) || string.IsNullOrWhiteSpace(yearsOfStudy))
            {
                MessageBox.Show("Please fill in all fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validate if age and years of study are numeric
            if (!int.TryParse(age, out _) || !int.TryParse(yearsOfStudy, out _))
            {
                MessageBox.Show("Age and Years of Study must be numbers.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Prepare the student data to save
            string studentData = $"ID: {id}, Name: {name}, Surname: {surname}, Age: {age}, Course: {course}, Years of Study: {yearsOfStudy}";

            try
            {
                // Save the data to a text file (append mode)
                string filePath = @"Data\StudentData.txt";
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine(studentData);
                }

                // Show confirmation message
                MessageBox.Show("Student data saved successfully!");

                // Clear the form after saving
                ShowStudentForm();
            }
            catch (Exception ex)
            {
                // Handle any errors that might occur during file operations
                MessageBox.Show($"Error saving data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }




    }
}
