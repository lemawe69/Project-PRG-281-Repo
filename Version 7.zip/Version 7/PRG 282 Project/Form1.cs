using PRG_282_Project.Business;

namespace PRG_282_Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void insertStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InsertStudentForm();
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
        //Home Page
        private void HomePageForm()
        {
            //
        }
        //Insert Student Form
        private void InsertStudentForm()
        {
            //New Logic Object
            Logic logic = new Logic();
            // Clear existing controls on the panel
            panel1.Controls.Clear();

            // Create labels and textboxes for student details

            Label lblID = new Label
            {
                Text = "Student ID:",
                Location = new Point(panel1.Width * 5 / 100, panel1.Height * 7 / 100),
                Width = panel1.Width * 40 / 100,
                Height = panel1.Height * 7 / 100,
                TextAlign = ContentAlignment.TopCenter,
                Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
            };
            TextBox txtID = new TextBox
            {
                Location = new Point(panel1.Width * 55 / 100, panel1.Height * 7 / 100),
                Width = panel1.Width * 40 / 100,
                Height = panel1.Height * 7 / 100
            };

            Label lblName = new Label
            {
                Text = "Name:",
                Location = new Point(panel1.Width * 5 / 100, panel1.Height * 21 / 100),
                Width = panel1.Width * 40 / 100,
                Height = panel1.Height * 7 / 100,
                TextAlign = ContentAlignment.TopCenter,
                Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
            };
            TextBox txtName = new TextBox
            {
                Location = new Point(panel1.Width * 55 / 100, panel1.Height * 21 / 100),
                Width = panel1.Width * 40 / 100,
                Height = panel1.Height * 7 / 100
            };

            Label lblSurname = new Label
            {
                Text = "Surname:",
                Location = new Point(panel1.Width * 5 / 100, panel1.Height * 35 / 100),
                Width = panel1.Width * 40 / 100,
                Height = panel1.Height * 7 / 100,
                TextAlign = ContentAlignment.TopCenter,
                Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
            };
            TextBox txtSurname = new TextBox
            {
                Location = new Point(panel1.Width * 55 / 100, panel1.Height * 35 / 100),
                Width = panel1.Width * 40 / 100,
                Height = panel1.Height * 7 / 100
            };

            Label lblAge = new Label
            {
                Text = "Age:",
                Location = new Point(panel1.Width * 5 / 100, panel1.Height * 49 / 100),
                Width = panel1.Width * 40 / 100,
                Height = panel1.Height * 7 / 100,
                TextAlign = ContentAlignment.TopCenter,
                Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
            };
            TextBox txtAge = new TextBox
            {
                Location = new Point(panel1.Width * 55 / 100, panel1.Height * 49 / 100),
                Width = panel1.Width * 40 / 100,
                Height = panel1.Height * 7 / 100
            };

            Label lblCourse = new Label
            {
                Text = "Course:",
                Location = new Point(panel1.Width * 5 / 100, panel1.Height * 63 / 100),
                Width = panel1.Width * 40 / 100,
                Height = panel1.Height * 7 / 100,
                TextAlign = ContentAlignment.TopCenter,
                Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
            };
            ComboBox comboCourse = new ComboBox
            {
                Location = new Point(panel1.Width * 55 / 100, panel1.Height * 63 / 100),
                Width = panel1.Width * 40 / 100,
                Height = panel1.Height * 7 / 100,
                DropDownStyle = ComboBoxStyle.DropDownList // This prevents users from typing a custom entry
            };

            // Add course options
            comboCourse.Items.AddRange(new string[] { "BComp", "BIT", "Diploma", "Certificate" });

            Label lblYoS = new Label
            {
                Text = "Years of Study:",
                Location = new Point(panel1.Width * 5 / 100, panel1.Height * 77 / 100),
                Width = panel1.Width * 40 / 100,
                Height = panel1.Height * 7 / 100,
                TextAlign = ContentAlignment.TopCenter,
                Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
            };
            TextBox txtYos = new TextBox
            {
                Location = new Point(panel1.Width * 55 / 100, panel1.Height * 77 / 100),
                Width = panel1.Width * 40 / 100,
                Height = panel1.Height * 7 / 100
            };

            // Add a button to save the input
            Button btnSave = new Button
            {
                Text = "Save",
                Location = new Point(panel1.Width * 35 / 100, panel1.Height * 90 / 100),
                Width = panel1.Width * 40 / 100,
                Height = panel1.Height * 7 / 100,
                Font = new Font(Font.FontFamily, 13, FontStyle.Bold),
                BackColor = Color.DarkCyan
            };
            btnSave.FlatStyle = FlatStyle.Flat;
            btnSave.FlatAppearance.BorderColor = Color.Black;
            btnSave.Click += (s, e) => logic.InsertStudent(txtID.Text, txtName.Text, txtSurname.Text, txtAge.Text, comboCourse.Text, txtYos.Text);


            // Add controls to the panel
            panel1.Controls.Add(lblID);
            panel1.Controls.Add(txtID);
            panel1.Controls.Add(lblName);
            panel1.Controls.Add(txtName);
            panel1.Controls.Add(lblSurname);
            panel1.Controls.Add(txtSurname);
            panel1.Controls.Add(lblAge);
            panel1.Controls.Add(txtAge);
            panel1.Controls.Add(lblCourse);
            panel1.Controls.Add(comboCourse);
            panel1.Controls.Add(lblYoS);
            panel1.Controls.Add(txtYos);
            panel1.Controls.Add(btnSave);
        }

        //View All Students Form
        private void ViewAllStudentsForm()
        {
            //Create new Logic Item
            Logic logic = new Logic();
            // Clears Panel
            panel1.Controls.Clear();

            // Create List Object for Student Data
            ListView listView = new ListView
            {
                Location = new Point((int)(panel1.Width * 5 / 100), (int)(panel1.Height * 15 / 100)),
                Width = (int)(panel1.Width * 90 / 100),
                Height = (int)(panel1.Height * 80 / 100),
                GridLines = true,
                FullRowSelect = true,
                View = View.Details,
                OwnerDraw = true
            };

            //Add Search Bar
            TextBox SearchBar = new TextBox
            {
                Location = new Point(panel1.Width * 50 / 100, panel1.Height * 5 / 100),
                Width = panel1.Width * 25 / 100,
                Height = (int)(panel1.Height * 5 / 100)
            };
            Button RefreshBtn = new Button
            {
                Text = "Refresh",
                Location = new Point(panel1.Width * 85 / 100, panel1.Height * 5 / 100),
                Width = (int)(panel1.Width * 1 / 10),
                Height = (int)(panel1.Height * 5 / 100),
                Font = new Font(Font.FontFamily, 8, FontStyle.Bold),
                BackColor = Color.DarkCyan
            };
            RefreshBtn.FlatStyle = FlatStyle.Flat;
            RefreshBtn.FlatAppearance.BorderColor = Color.Black;
            RefreshBtn.Click += (s, e) => Program.SearchedStudents = new List<Student>();
            RefreshBtn.Click += (s, e) => ViewAllStudentsForm();

            Button SearchBtn = new Button
            {
                Text = "Search",
                Location = new Point(panel1.Width * 75 / 100, panel1.Height * 5 / 100),
                Width = (int)(panel1.Width * 1 / 10),
                Height = (int)(panel1.Height * 5 / 100),
                Font = new Font(Font.FontFamily, 8, FontStyle.Bold),
                BackColor = Color.DarkCyan
            };
            SearchBtn.FlatStyle = FlatStyle.Flat;
            SearchBtn.FlatAppearance.BorderColor = Color.Black;
            SearchBtn.Click += (s, e) => logic.SearchStudents(SearchBar.Text);
            SearchBtn.Click += (s, e) => SearchBar.Refresh();
            SearchBtn.Click += (s, e) => ViewAllStudentsForm();


            // Adds Columns
            listView.Columns.Add("Student ID", listView.Width / 6, HorizontalAlignment.Left);
            listView.Columns.Add("Name", listView.Width / 6, HorizontalAlignment.Left);
            listView.Columns.Add("Surname", listView.Width / 6, HorizontalAlignment.Left);
            listView.Columns.Add("Age", listView.Width / 6, HorizontalAlignment.Left);
            listView.Columns.Add("Course", listView.Width / 6, HorizontalAlignment.Left);
            listView.Columns.Add("Year of Study", listView.Width / 6, HorizontalAlignment.Left);

            //If there is searched Students
            if (Program.SearchedStudents.Count > 0)
            {
                // Adds Students to List
                foreach (Student student in Program.SearchedStudents)
                {
                    ListViewItem item = new ListViewItem(Convert.ToString(student.StudentID));
                    item.SubItems.Add(student.Name);
                    item.SubItems.Add(student.Surname);
                    item.SubItems.Add(Convert.ToString(student.Age));
                    item.SubItems.Add(student.Course);
                    item.SubItems.Add(Convert.ToString(student.YearOfStudy));

                    // Adds item to listView
                    listView.Items.Add(item);
                }
            }
            else
            {
                // Adds Students to List
                foreach (Student student in Program.Students)
                {
                    ListViewItem item = new ListViewItem(Convert.ToString(student.StudentID));
                    item.SubItems.Add(student.Name);
                    item.SubItems.Add(student.Surname);
                    item.SubItems.Add(Convert.ToString(student.Age));
                    item.SubItems.Add(student.Course);
                    item.SubItems.Add(Convert.ToString(student.YearOfStudy));

                    // Adds item to listView
                    listView.Items.Add(item);
                }
            }

            // Custom draw event handlers
            listView.DrawColumnHeader += ListView_DrawColumnHeader;
            listView.DrawItem += ListView_DrawItem;

            // Adds List View to Panel
            panel1.Controls.Add(SearchBar);
            panel1.Controls.Add(SearchBtn);
            panel1.Controls.Add(RefreshBtn);
            panel1.Controls.Add(listView);
        }

        // Event handler for drawing the column headers
        private void ListView_DrawColumnHeader(object sender, DrawListViewColumnHeaderEventArgs e)
        {
            // Set the background color and text format
            using (Brush headerBackgroundBrush = new SolidBrush(Color.LightGray))
            using (Font headerFont = new Font(e.Font, FontStyle.Bold))
            {
                e.Graphics.FillRectangle(headerBackgroundBrush, e.Bounds);
                TextRenderer.DrawText(e.Graphics, e.Header.Text, headerFont, e.Bounds, Color.Black, TextFormatFlags.Left);
            }
            e.DrawDefault = false;
        }

        // This event must be handled even if not custom drawing the items
        private void ListView_DrawItem(object sender, DrawListViewItemEventArgs e)
        {
            e.DrawDefault = true;
        }

        private void allStudentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewAllStudentsForm();
        }

        private ListView lstStudents;
        private TextBox txtID, txtName, txtSurname, txtAge, txtYos;
        private ComboBox comboCourse;

        private void ShowUpdateStudentForm()
        {
            // Clear existing controls on the panel
            panel1.Controls.Clear();

            // Initialize the ListBox for displaying student entries
            lstStudents = new ListView
            {
                Location = new Point(panel1.Width * 55 / 100, panel1.Height * 5 / 100),
                Width = panel1.Width * 40 / 100,
                Height = panel1.Height * 90 / 100,
                GridLines = true,
                FullRowSelect = true,
                View = View.Details,
                OwnerDraw = true
            };

            //Make Columbs
            lstStudents.Columns.Add("Student ID", lstStudents.Width / 3, HorizontalAlignment.Left);
            lstStudents.Columns.Add("Name", lstStudents.Width / 3, HorizontalAlignment.Left);
            lstStudents.Columns.Add("Surname", lstStudents.Width / 3, HorizontalAlignment.Left);

            //adds Students to list
            foreach (Student student in Program.Students)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(student.StudentID));
                item.SubItems.Add(student.Name);
                item.SubItems.Add(student.Surname);

                //Addd item
                lstStudents.Items.Add(item);
            }

            // Custom draw event handlers
            lstStudents.DrawColumnHeader += ListView_DrawColumnHeader;
            lstStudents.DrawItem += ListView_DrawItem;

            // Create labels and textboxes for student details
            Label lblID = new Label
            {
                Text = "Student ID:",
                Location = new Point(panel1.Width * 5 / 100, panel1.Height * 7 / 100),
                Width = panel1.Width * 15 / 100,
                Height = panel1.Height * 7 / 100,
                TextAlign = ContentAlignment.TopCenter,
                Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
            };
            txtID = new TextBox
            {
                Location = new Point(panel1.Width * 30 / 100, panel1.Height * 7 / 100),
                Width = panel1.Width * 20 / 100,
                Height = panel1.Height * 7 / 100
            };

            Label lblName = new Label
            {
                Text = "Name:",
                Location = new Point(panel1.Width * 5 / 100, panel1.Height * 21 / 100),
                Width = panel1.Width * 15 / 100,
                Height = panel1.Height * 7 / 100,
                TextAlign = ContentAlignment.TopCenter,
                Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
            };
            txtName = new TextBox
            {
                Location = new Point(panel1.Width * 30 / 100, panel1.Height * 21 / 100),
                Width = panel1.Width * 20 / 100,
                Height = panel1.Height * 7 / 100
            };

            Label lblSurname = new Label
            {
                Text = "Surname:",
                Location = new Point(panel1.Width * 5 / 100, panel1.Height * 35 / 100),
                Width = panel1.Width * 15 / 100,
                Height = panel1.Height * 7 / 100,
                TextAlign = ContentAlignment.TopCenter,
                Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
            };
            txtSurname = new TextBox
            {
                Location = new Point(panel1.Width * 30 / 100, panel1.Height * 35 / 100),
                Width = panel1.Width * 20 / 100,
                Height = panel1.Height * 7 / 100
            };

            Label lblAge = new Label
            {
                Text = "Age:",
                Location = new Point(panel1.Width * 5 / 100, panel1.Height * 49 / 100),
                Width = panel1.Width * 15 / 100,
                Height = panel1.Height * 7 / 100,
                TextAlign = ContentAlignment.TopCenter,
                Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
            };
            txtAge = new TextBox
            {
                Location = new Point(panel1.Width * 30 / 100, panel1.Height * 49 / 100),
                Width = panel1.Width * 20 / 100,
                Height = panel1.Height * 7 / 100
            };

            Label lblCourse = new Label
            {
                Text = "Course:",
                Location = new Point(panel1.Width * 5 / 100, panel1.Height * 63 / 100),
                Width = panel1.Width * 15 / 100,
                Height = panel1.Height * 7 / 100,
                TextAlign = ContentAlignment.TopCenter,
                Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
            };
            comboCourse = new ComboBox
            {
                Location = new Point(panel1.Width * 30 / 100, panel1.Height * 63 / 100),
                Width = panel1.Width * 20 / 100,
                Height = panel1.Height * 7 / 100,
                DropDownStyle = ComboBoxStyle.DropDownList // This prevents users from typing a custom entry
            };

            // Add course options
            comboCourse.Items.AddRange(new string[] { "BComp", "BIT", "Diploma", "Certificate" });

            Label lblYoS = new Label
            {
                Text = "Years of Study:",
                Location = new Point(panel1.Width * 3 / 100, panel1.Height * 77 / 100),
                Width = panel1.Width * 20 / 100,
                Height = panel1.Height * 7 / 100,
                TextAlign = ContentAlignment.TopCenter,
                Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
            };
            txtYos = new TextBox
            {
                Location = new Point(panel1.Width * 30 / 100, panel1.Height * 77 / 100),
                Width = panel1.Width * 20 / 100,
                Height = panel1.Height * 7 / 100
            };


            // Add a button to update the student details
            Button btnUpdate = new Button
            {
                Text = "Update",
                Location = new Point(panel1.Width * 15 / 100, panel1.Height * 90 / 100),
                Width = panel1.Width * 20 / 100,
                Height = panel1.Height * 7 / 100,
                Font = new Font(Font.FontFamily, 13, FontStyle.Bold),
                BackColor = Color.DarkCyan
            };
            btnUpdate.FlatStyle = FlatStyle.Flat;
            btnUpdate.FlatAppearance.BorderColor = Color.Black;
            btnUpdate.Click += (s, e) => UpdateBtnClick();

            // Add controls to the panel
            panel1.Controls.Add(lblID);
            panel1.Controls.Add(txtID);
            panel1.Controls.Add(lblName);
            panel1.Controls.Add(txtName);
            panel1.Controls.Add(lblSurname);
            panel1.Controls.Add(txtSurname);
            panel1.Controls.Add(lblAge);
            panel1.Controls.Add(txtAge);
            panel1.Controls.Add(lblCourse);
            panel1.Controls.Add(comboCourse);
            panel1.Controls.Add(lblYoS);
            panel1.Controls.Add(txtYos);
            panel1.Controls.Add(btnUpdate);
            panel1.Controls.Add(lstStudents);
        }

        private void UpdateBtnClick()
        {
            //New Logic Onject
            Logic logic = new Logic();

            if (lstStudents.SelectedItems.Count > 0)
            {
                // Ensure all fields have values before attempting to update
                if (string.IsNullOrWhiteSpace(txtID.Text) || string.IsNullOrWhiteSpace(txtName.Text) ||
                string.IsNullOrWhiteSpace(txtSurname.Text) || string.IsNullOrWhiteSpace(txtAge.Text) ||
                string.IsNullOrWhiteSpace(comboCourse.Text) || string.IsNullOrWhiteSpace(txtYos.Text))
                {
                    MessageBox.Show("Please fill in all fields.",
                                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                else if (!int.TryParse(txtID.Text, out _) || !int.TryParse(txtAge.Text, out _) || !int.TryParse(txtYos.Text, out _))
                {
                    MessageBox.Show("ID, Age, Year of Study Must be Int!",
                                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                else
                {
                    // Get Selected Student
                    ListViewItem selectedStudent = lstStudents.SelectedItems[0];

                    // Run Update Student
                    logic.UpdateStudent(selectedStudent.Text, txtID.Text, txtName.Text, txtSurname.Text, txtAge.Text, comboCourse.Text, txtYos.Text);

                    MessageBox.Show("Student Updated Successfully");

                    //Clear TextBoxes
                    txtID.Text = "";
                    txtName.Text = "";
                    txtSurname.Text = "";
                    txtAge.Text = "";
                    comboCourse.Text = "";
                    txtYos.Text = "";

                    // Show Update Student Form Again
                    ShowUpdateStudentForm();
                }
            }
            else
            {
                MessageBox.Show("Please Select a Student from the List Box");
            }
        }

        //Summary Form
        private void ViewSummaryForm()
        {
            //Clears Panel1
            panel1.Controls.Clear();

            //Add Student Sammary label
            Label StudentSummaryHeading = new Label
            {
                Location = new Point(panel1.Width * 5 / 100, panel1.Height * 5 / 100),
                Width = (int)(panel1.Width * 90 / 100),
                Height = (int)(panel1.Height * 30 / 100),
                Text = "Student Summary",
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font(Font.FontFamily, 40, FontStyle.Bold)
            };

            //First Year Label
            Label FirstYearLable = new Label
            {
                Location = new Point(panel1.Width * 5 / 100, panel1.Height * 35 / 100),
                Width = (int)(panel1.Width * 40 / 100),
                Height = (int)(panel1.Height * 10 / 100),
                Text = $"Total First Year Students : {Program.TotalFirstYears}",
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font(Font.FontFamily, 13, FontStyle.Regular)
            };
            Label AverageAgeFirstYearLable = new Label
            {
                Location = new Point(panel1.Width * 55 / 100, panel1.Height * 35 / 100),
                Width = (int)(panel1.Width * 40 / 100),
                Height = (int)(panel1.Height * 10 / 100),
                Text = $"Average First Year Age : {Program.AverageFirstYearAge}",
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font(Font.FontFamily, 13, FontStyle.Regular)
            };

            //First Year Label
            Label SecondYearLable = new Label
            {
                Location = new Point(panel1.Width * 5 / 100, panel1.Height * 50 / 100),
                Width = (int)(panel1.Width * 40 / 100),
                Height = (int)(panel1.Height * 10 / 100),
                Text = $"Total Second Year Students : {Program.TotalSecondYears}",
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font(Font.FontFamily, 13, FontStyle.Regular)
            };
            Label AverageAgeSecondYearLable = new Label
            {
                Location = new Point(panel1.Width * 55 / 100, panel1.Height * 50 / 100),
                Width = (int)(panel1.Width * 40 / 100),
                Height = (int)(panel1.Height * 10 / 100),
                Text = $"Average Second Year Age : {Program.AverageSecondYearAge}",
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font(Font.FontFamily, 13, FontStyle.Regular)
            };

            //First Year Label
            Label ThirdYearLable = new Label
            {
                Location = new Point(panel1.Width * 5 / 100, panel1.Height * 65 / 100),
                Width = (int)(panel1.Width * 40 / 100),
                Height = (int)(panel1.Height * 10 / 100),
                Text = $"Total Third Year Students : {Program.TotalThirdYears}",
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font(Font.FontFamily, 13, FontStyle.Regular)
            };
            Label AverageAgeThirdYearLable = new Label
            {
                Location = new Point(panel1.Width * 55 / 100, panel1.Height * 65 / 100),
                Width = (int)(panel1.Width * 40 / 100),
                Height = (int)(panel1.Height * 10 / 100),
                Text = $"Average Third Year Age : {Program.AverageThirdYearAge}",
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font(Font.FontFamily, 13, FontStyle.Regular)
            };

            //First Year Label
            Label ForthYearLable = new Label
            {
                Location = new Point(panel1.Width * 5 / 100, panel1.Height * 80 / 100),
                Width = (int)(panel1.Width * 40 / 100),
                Height = (int)(panel1.Height * 10 / 100),
                Text = $"Total Forth Year Students : {Program.TotalForthYears}",
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font(Font.FontFamily, 13, FontStyle.Regular)
            };
            Label AverageAgeForthYearLable = new Label
            {
                Location = new Point(panel1.Width * 55 / 100, panel1.Height * 80 / 100),
                Width = (int)(panel1.Width * 40 / 100),
                Height = (int)(panel1.Height * 10 / 100),
                Text = $"Average Forth Year Age : {Program.AverageForthYearAge}",
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font(Font.FontFamily, 13, FontStyle.Regular)
            };

            //Add To panel1
            panel1.Controls.Add(StudentSummaryHeading);
            panel1.Controls.Add(FirstYearLable);
            panel1.Controls.Add(AverageAgeFirstYearLable);
            panel1.Controls.Add(SecondYearLable);
            panel1.Controls.Add(AverageAgeSecondYearLable);
            panel1.Controls.Add(ThirdYearLable);
            panel1.Controls.Add(AverageAgeThirdYearLable);
            panel1.Controls.Add(ForthYearLable);
            panel1.Controls.Add(AverageAgeForthYearLable);
        }

        private void summaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //New Logic Object
            Logic logic = new Logic();
            logic.SummaryCalculation();

            ViewSummaryForm();
        }

        private void updateStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowUpdateStudentForm();
        }

        private void deleteStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowDeleteStudentForm();

        }

        private ListView lstViewStudents;
        private Button btnDelete;


        private void ShowDeleteStudentForm()
        {
            try
            {
                // Clear existing controls on the panel
                panel1.Controls.Clear();

                // Initialize the ListView for displaying students
                lstViewStudents = new ListView
                {
                    Location = new Point(20, 20),
                    Width = 500,
                    Height = 300,
                    View = View.Details,
                    FullRowSelect = true,
                    GridLines = true
                };

                // Add columns to the ListView
                lstViewStudents.Columns.Add("ID", 80);
                lstViewStudents.Columns.Add("Name", 100);
                lstViewStudents.Columns.Add("Surname", 100);
                lstViewStudents.Columns.Add("Age", 50);
                lstViewStudents.Columns.Add("Course", 100);
                lstViewStudents.Columns.Add("Years of Study", 100);

                // Load students into the ListView
                LoadStudentsToListView();

                // Create a button to delete the selected student
                btnDelete = new Button
                {
                    Text = "Delete",
                    Location = new Point(20, 340)
                };
                btnDelete.Click += (s, e) => DeleteSelectedStudent();

                // Add controls to the panel
                panel1.Controls.Add(lstViewStudents);
                panel1.Controls.Add(btnDelete);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading the delete student form: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadStudentsToListView()
        {
            string filePath = @"Data/StudentData.txt";

            try
            {
                // Clear existing items in the ListView
                lstViewStudents.Items.Clear();

                // Check if the file exists before reading
                if (!File.Exists(filePath))
                {
                    MessageBox.Show("Student data file not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                var lines = File.ReadAllLines(filePath);

                // Check if the file is empty
                if (lines.Length == 0)
                {
                    MessageBox.Show("Student data file is empty.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                // Loop through each line in the file
                foreach (var line in lines)
                {
                    try
                    {
                        if (!string.IsNullOrWhiteSpace(line))
                        {
                            // Split the line by commas
                            string[] details = line.Split(',');

                            // Ensure we have exactly 6 fields before accessing indices
                            if (details.Length < 6)
                            {
                                MessageBox.Show($"Incorrect data format: {line}", "Parsing Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                continue;
                            }

                            // Extract the student details
                            string id = details[0].Trim();
                            string name = details[1].Trim();
                            string surname = details[2].Trim();
                            string age = details[3].Trim();
                            string course = details[4].Trim();
                            string yos = details[5].Trim();

                            // Add the student data as a ListViewItem
                            ListViewItem item = new ListViewItem(id);
                            item.SubItems.Add(name);
                            item.SubItems.Add(surname);
                            item.SubItems.Add(age);
                            item.SubItems.Add(course);
                            item.SubItems.Add(yos);
                            lstViewStudents.Items.Add(item);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error parsing line: {line}\n{ex.Message}", "Parsing Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading students: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void DeleteSelectedStudent()
        {
            if (lstViewStudents.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select a student to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Get the selected student's ID
            string selectedStudentID = lstViewStudents.SelectedItems[0].Text;

            string filePath = @"Data/StudentData.txt";
            if (File.Exists(filePath))
            {
                var lines = File.ReadAllLines(filePath).ToList();
                bool studentDeleted = false;

                // Loop through the lines to find and delete the selected student
                for (int i = 0; i < lines.Count; i++)
                {
                    string[] details = lines[i].Split(',');
                    if (details.Length >= 6 && details[0].Trim() == selectedStudentID)
                    {
                        lines.RemoveAt(i); // Remove the student's line
                        studentDeleted = true;
                        break;
                    }
                }

                // Save the updated list back to the file if a student was deleted
                if (studentDeleted)
                {
                    try
                    {
                        File.WriteAllLines(filePath, lines);
                        MessageBox.Show("Student deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Refresh the ListView after deletion
                        LoadStudentsToListView();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error deleting student: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Student not found in the records.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }



    }
}
