﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG_282_Project.Business
{
	internal class Logic
	{
		//Creating Students From Data Base
		public void FormatData(string[] AllData)
		{
			foreach (var item in AllData)
			{
				//Splits Line
				string[] StudentInfo = item.Split(new char[] { ',' });

				//Creates new student
				int studentID = Convert.ToInt32(StudentInfo[0]);
				string name = StudentInfo[1];
				string surname = StudentInfo[2];
				int age = Convert.ToInt32(StudentInfo[3]);
				string course = StudentInfo[4];
				int yearOfStudy = Convert.ToInt32(StudentInfo[5]);

				Student newStudent = new Student(studentID,name, surname, age, course, yearOfStudy);

				//Adds Student to List
				Program.Students.Add(newStudent);
			}
		}

		//Insert Student
		public void InsertStudent(string id, string name, string surname, string age, string course, string yearOfStudy)
		{
			MessageBox.Show($"Student Added\n" +
				$"ID : {id}\n" +
				$"Name : {name}\n" +
				$"Surname : {surname}\n" +
				$"Age : {age}\n" +
				$"Course : {course}\n" +
				$"Year of Study : {yearOfStudy}");
		}
	}
}
