using PRG_282_Project.Business;

namespace PRG_282_Project
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
		{

		}

		private void insertStudentToolStripMenuItem_Click(object sender, EventArgs e)
		{
			InsertStudentForm();
		}

		private void label1_Click_1(object sender, EventArgs e)
		{

		}

		//Insert Student Form
		private void InsertStudentForm()
		{
			//New Logic Object
			Logic logic = new Logic();
			// Clear existing controls on the panel
			panel1.Controls.Clear();

			// Create labels and textboxes for student details

			Label lblID = new Label { Text = "Student ID:", Location = new Point(20, 20) };
			TextBox txtID = new TextBox { Location = new Point(120, 20), Width = 200 };

			Label lblName = new Label { Text = "Name:", Location = new Point(20, 60) };
			TextBox txtName = new TextBox { Location = new Point(120, 60), Width = 200 };

			Label lblSurname = new Label { Text = "Surname:", Location = new Point(20, 100) };
			TextBox txtSurname = new TextBox { Location = new Point(120, 100), Width = 200 };

			Label lblAge = new Label { Text = "Age:", Location = new Point(20, 140) };
			TextBox txtAge = new TextBox { Location = new Point(120, 140), Width = 200 };

			Label lblCourse = new Label { Text = "Course:", Location = new Point(20, 180) };
			TextBox txtCourse = new TextBox { Location = new Point(120, 180), Width = 200 };

			Label lblYoS = new Label { Text = "Years of Study:", Location = new Point(20, 220) };
			TextBox txtYos = new TextBox { Location = new Point(120, 220), Width = 200 };

			// Add a button to save the input
			Button btnSave = new Button
			{
				Text = "Save",
				Location = new Point(100, 260)
			};
			btnSave.Click += (s, e) => logic.InsertStudent(txtID.Text, txtName.Text, txtSurname.Text, txtAge.Text, txtCourse.Text, txtYos.Text);


			// Add controls to the panel
			panel1.Controls.Add(lblID);
			panel1.Controls.Add(txtID);
			panel1.Controls.Add(lblName);
			panel1.Controls.Add(txtName);
			panel1.Controls.Add(lblSurname);
			panel1.Controls.Add(txtSurname);
			panel1.Controls.Add(lblAge);
			panel1.Controls.Add(txtAge);
			panel1.Controls.Add(lblCourse);
			panel1.Controls.Add(txtCourse);
			panel1.Controls.Add(lblYoS);
			panel1.Controls.Add(txtYos);
			panel1.Controls.Add(btnSave);
		}

		//View All Students Form
		private void ViewAllStudentsForm()
		{
			// Clears Panel
			panel1.Controls.Clear();

			// Create List Object for Student Data
			ListView listView = new ListView
			{
				Location = new Point((int)(panel1.Width * 5 / 100), (int)(panel1.Height * 15 / 100)),
				Width = (int)(panel1.Width * 90 / 100),
				Height = (int)(panel1.Height * 80 / 100),
				GridLines = true,
				FullRowSelect = true,
				View = View.Details,
				OwnerDraw = true // Enable custom drawing
			};

			// Adds Columns
			listView.Columns.Add("Student ID", listView.Width / 6, HorizontalAlignment.Left);
			listView.Columns.Add("Name", listView.Width / 6, HorizontalAlignment.Left);
			listView.Columns.Add("Surname", listView.Width / 6, HorizontalAlignment.Left);
			listView.Columns.Add("Age", listView.Width / 6, HorizontalAlignment.Left);
			listView.Columns.Add("Course", listView.Width / 6, HorizontalAlignment.Left);
			listView.Columns.Add("Year of Study", listView.Width / 6, HorizontalAlignment.Left);

			// Adds Students to List
			foreach (Student student in Program.Students)
			{
				ListViewItem item = new ListViewItem(Convert.ToString(student.StudentID));
				item.SubItems.Add(student.Name);
				item.SubItems.Add(student.Surname);
				item.SubItems.Add(Convert.ToString(student.Age));
				item.SubItems.Add(student.Course);
				item.SubItems.Add(Convert.ToString(student.YearOfStudy));

				// Adds item to listView
				listView.Items.Add(item);
			}

			// Custom draw event handlers
			listView.DrawColumnHeader += ListView_DrawColumnHeader;
			listView.DrawItem += ListView_DrawItem; // Required even if not custom drawing items

			// Adds List View to Panel
			panel1.Controls.Add(listView);
		}

		// Event handler for drawing the column headers
		private void ListView_DrawColumnHeader(object sender, DrawListViewColumnHeaderEventArgs e)
		{
			// Set the background color and text format
			using (Brush headerBackgroundBrush = new SolidBrush(Color.LightGray))
			using (Font headerFont = new Font(e.Font, FontStyle.Bold))
			{
				e.Graphics.FillRectangle(headerBackgroundBrush, e.Bounds);
				TextRenderer.DrawText(e.Graphics, e.Header.Text, headerFont, e.Bounds, Color.Black, TextFormatFlags.Left);
			}
			e.DrawDefault = false;
		}

		// This event must be handled even if not custom drawing the items
		private void ListView_DrawItem(object sender, DrawListViewItemEventArgs e)
		{
			e.DrawDefault = true;
		}

		private void allStudentsToolStripMenuItem_Click(object sender, EventArgs e)
		{
			ViewAllStudentsForm();
		}
	}
}
