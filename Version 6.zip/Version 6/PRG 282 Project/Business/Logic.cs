﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG_282_Project.Business
{
	internal class Logic
	{
		//Creating Students From Data Base
		public void FormatData(string[] AllData)
		{
			foreach (var item in AllData)
			{
				//Splits Line
				string[] StudentInfo = item.Split(new char[] { ',' });

				//Creates new student
				int studentID = Convert.ToInt32(StudentInfo[0]);
				string name = StudentInfo[1];
				string surname = StudentInfo[2];
				int age = Convert.ToInt32(StudentInfo[3]);
				string course = StudentInfo[4];
				int yearOfStudy = Convert.ToInt32(StudentInfo[5]);

				Student newStudent = new Student(studentID,name, surname, age, course, yearOfStudy);

				//Adds Student to List
				Program.Students.Add(newStudent);
			}
		}

		//Insert Student
		public void InsertStudent(string id, string name, string surname, string age, string course, string yearOfStudy)
		{
			MessageBox.Show($"Student Added\n" +
				$"ID : {id}\n" +
				$"Name : {name}\n" +
				$"Surname : {surname}\n" +
				$"Age : {age}\n" +
				$"Course : {course}\n" +
				$"Year of Study : {yearOfStudy}");


		}

		//Search For Student
		public void SearchStudents(string SearchedText)
		{
			SearchedText = SearchedText.ToLower();
			//Clears Searched List
			Program.SearchedStudents = new List<Student>();

			foreach (Student student in Program.Students)
			{
				if (student.StudentID.ToString().Contains(SearchedText) ||
					student.Name.ToLower().Contains(SearchedText) ||
					student.Surname.ToLower().Contains(SearchedText) ||
					student.Age.ToString().Contains(SearchedText) ||
					student.Course.ToLower().Contains(SearchedText) ||
					student.YearOfStudy.ToString().Contains(SearchedText))
				{
					Program.SearchedStudents.Add(student);
				}
			}

			if (Program.SearchedStudents.Count == 0)
			{
				MessageBox.Show("No Student Found From Searched Text");
			}
		}
		//Update Student
		public void UpdateStudent(string selectedStudentID, string id, string name, string surname, string age, string course, string yos)
		{
			foreach (Student student in Program.Students)
			{
				if (student.StudentID == Convert.ToInt32(selectedStudentID))
				{
					student.StudentID = Convert.ToInt32(id);
					student.Name = name;
					student.Surname = surname;
					student.Age = Convert.ToInt32(age);
					student.Course = course;
					student.YearOfStudy = Convert.ToInt32(yos);
				}
			}
		}

		//Calculation for Average Age
		public void SummaryCalculation()
		{
			int TotalFirstYearAge = 0;
			int TotalSecondYearAge = 0;
			int TotalThirdYearAge = 0;
			int TotalForthYearAge = 0;

			int TotalFirstYears = 0;
			int TotalSecondYears = 0;
			int TotalThirdYears = 0;
			int TotalForthYears = 0;

			//Loops Through Students
			foreach (Student student in Program.Students)
			{
				if (student.YearOfStudy == 1)
				{
					TotalFirstYearAge += student.Age;
					TotalFirstYears += 1;
				}
				if (student.YearOfStudy == 2)
				{
					TotalSecondYearAge += student.Age;
					TotalSecondYears += 1;
				}
				if (student.YearOfStudy == 3)
				{
					TotalThirdYearAge += student.Age;
					TotalThirdYears += 1;
				}
				if (student.YearOfStudy == 4)
				{
					TotalForthYearAge += student.Age;
					TotalForthYears += 1;
				}
			}

			//Calculate Data and save it
			Program.TotalFirstYears = TotalFirstYears;
			Program.TotalSecondYears = TotalSecondYears;
			Program.TotalThirdYears = TotalThirdYears;
			Program.TotalForthYears = TotalForthYears;

			Program.AverageFirstYearAge = (int)(TotalFirstYearAge / TotalFirstYears);
			Program.AverageSecondYearAge = (int)(TotalSecondYearAge / TotalSecondYears);
			Program.AverageThirdYearAge = (int)(TotalThirdYearAge / TotalThirdYears);
			Program.AverageForthYearAge = (int)(TotalForthYearAge / TotalForthYears);
		}

	}
}
