﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using PRG_282_Project.Business;

namespace PRG_282_Project.Data
{
	internal class DataHandler
	{
		//Create new logic object
		Logic logic = new Logic();
		//Data Path
		public static string DataPath = @"Data\StudentData.txt";
		public void GetStudentData()
		{
			//Get Data From Text File
			string[] AllData = File.ReadAllLines(DataPath);

			//Creates Student
			logic.FormatData(AllData);
		}
	}
}
