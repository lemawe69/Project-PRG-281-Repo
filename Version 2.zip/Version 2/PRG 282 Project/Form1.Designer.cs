﻿namespace PRG_282_Project
{
	partial class Form1
	{
		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			menuStrip1 = new MenuStrip();
			homeToolStripMenuItem = new ToolStripMenuItem();
			editToolStripMenuItem = new ToolStripMenuItem();
			insertStudentToolStripMenuItem = new ToolStripMenuItem();
			updateStudentToolStripMenuItem = new ToolStripMenuItem();
			deleteStudentToolStripMenuItem = new ToolStripMenuItem();
			viewToolStripMenuItem = new ToolStripMenuItem();
			allStudentsToolStripMenuItem = new ToolStripMenuItem();
			summaryToolStripMenuItem = new ToolStripMenuItem();
			menuStrip1.SuspendLayout();
			SuspendLayout();
			// 
			// menuStrip1
			// 
			menuStrip1.BackColor = SystemColors.ActiveCaption;
			menuStrip1.ImageScalingSize = new Size(20, 20);
			menuStrip1.Items.AddRange(new ToolStripItem[] { homeToolStripMenuItem, editToolStripMenuItem, viewToolStripMenuItem });
			menuStrip1.Location = new Point(0, 0);
			menuStrip1.Name = "menuStrip1";
			menuStrip1.Size = new Size(914, 28);
			menuStrip1.TabIndex = 0;
			menuStrip1.Text = "menuStrip1";
			// 
			// homeToolStripMenuItem
			// 
			homeToolStripMenuItem.Name = "homeToolStripMenuItem";
			homeToolStripMenuItem.Size = new Size(64, 24);
			homeToolStripMenuItem.Text = "Home";
			// 
			// editToolStripMenuItem
			// 
			editToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { insertStudentToolStripMenuItem, updateStudentToolStripMenuItem, deleteStudentToolStripMenuItem });
			editToolStripMenuItem.Name = "editToolStripMenuItem";
			editToolStripMenuItem.Size = new Size(49, 24);
			editToolStripMenuItem.Text = "Edit";
			// 
			// insertStudentToolStripMenuItem
			// 
			insertStudentToolStripMenuItem.BackColor = SystemColors.Control;
			insertStudentToolStripMenuItem.Name = "insertStudentToolStripMenuItem";
			insertStudentToolStripMenuItem.Size = new Size(224, 26);
			insertStudentToolStripMenuItem.Text = "Insert Student";
			// 
			// updateStudentToolStripMenuItem
			// 
			updateStudentToolStripMenuItem.Name = "updateStudentToolStripMenuItem";
			updateStudentToolStripMenuItem.Size = new Size(224, 26);
			updateStudentToolStripMenuItem.Text = "Update Student";
			// 
			// deleteStudentToolStripMenuItem
			// 
			deleteStudentToolStripMenuItem.Name = "deleteStudentToolStripMenuItem";
			deleteStudentToolStripMenuItem.Size = new Size(224, 26);
			deleteStudentToolStripMenuItem.Text = "Delete Student";
			// 
			// viewToolStripMenuItem
			// 
			viewToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { allStudentsToolStripMenuItem, summaryToolStripMenuItem });
			viewToolStripMenuItem.Name = "viewToolStripMenuItem";
			viewToolStripMenuItem.Size = new Size(55, 24);
			viewToolStripMenuItem.Text = "View";
			// 
			// allStudentsToolStripMenuItem
			// 
			allStudentsToolStripMenuItem.Name = "allStudentsToolStripMenuItem";
			allStudentsToolStripMenuItem.Size = new Size(171, 26);
			allStudentsToolStripMenuItem.Text = "All Students";
			// 
			// summaryToolStripMenuItem
			// 
			summaryToolStripMenuItem.Name = "summaryToolStripMenuItem";
			summaryToolStripMenuItem.Size = new Size(171, 26);
			summaryToolStripMenuItem.Text = "Summary";
			// 
			// Form1
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(914, 600);
			Controls.Add(menuStrip1);
			Margin = new Padding(3, 4, 3, 4);
			Name = "Form1";
			Text = "Form1";
			menuStrip1.ResumeLayout(false);
			menuStrip1.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private MenuStrip menuStrip1;
		private ToolStripMenuItem homeToolStripMenuItem;
		private ToolStripMenuItem editToolStripMenuItem;
		private ToolStripMenuItem insertStudentToolStripMenuItem;
		private ToolStripMenuItem updateStudentToolStripMenuItem;
		private ToolStripMenuItem deleteStudentToolStripMenuItem;
		private ToolStripMenuItem viewToolStripMenuItem;
		private ToolStripMenuItem allStudentsToolStripMenuItem;
		private ToolStripMenuItem summaryToolStripMenuItem;
	}
}
