﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using PRG_282_Project.Business;

namespace PRG_282_Project.Data
{
	internal class DataHandler
	{
		//Create new logic object
		Logic logic = new Logic();
		//Data Path
		public static string DataPath = Path.Combine(
	Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..")),
	"Data",
	"StudentData.txt");
		public void GetStudentData()
		{
			//Get Data From Text File
			string[] AllData = File.ReadAllLines(DataPath);

			//Creates Student
			logic.FormatData(AllData);
		}

		//Update Text File
		public void UpdateData()
		{
			//Make totel text Empty
			string TotalText = String.Empty;

			//Adds Students to total Text
			foreach (Student student in Program.Students)
			{
				string id = student.StudentID.ToString();
				string name = student.Name;
				string surmame = student.Surname;
				string age = student.Age.ToString();
				string course = student.Course;
				string yearofstudy = student.YearOfStudy.ToString();

				TotalText += $"{id},{name},{surmame},{age},{course},{yearofstudy}\n";
			}

			File.WriteAllText(DataPath, TotalText);
		}
	}
}
